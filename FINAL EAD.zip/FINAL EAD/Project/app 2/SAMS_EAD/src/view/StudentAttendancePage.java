package view;

import javax.swing.*;
import java.awt.*;

public class StudentAttendancePage extends JPanel {

    public StudentAttendancePage(MainFrame frame) {

        setBackground(new Color(20,22,40));
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Student Attendance Overview");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setBorder(BorderFactory.createEmptyBorder(25,35,15,0));
        add(title, BorderLayout.NORTH);

        JTextArea area = new JTextArea("Attendance information:\n\n• Present %\n• Absent Records\n• Monthly Analysis");
        area.setBackground(new Color(32,36,60));
        area.setForeground(Color.WHITE);
        area.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        area.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        area.setEditable(false);

        add(area, BorderLayout.CENTER);

        JButton btnBack = new JButton("Back to Student Dashboard");
        btnBack.setBackground(new Color(120,90,255));
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(e ->
                frame.cardLayout.show(frame.contentPanel, "STUDENT_DASHBOARD")
        );

        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(20,22,40));
        bottom.add(btnBack);

        add(bottom, BorderLayout.SOUTH);
    }
}
