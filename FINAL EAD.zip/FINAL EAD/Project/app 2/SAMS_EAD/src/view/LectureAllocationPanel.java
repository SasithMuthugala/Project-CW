package view;

import controller.LectureAllocationController;
import model.LectureAllocation;

import javax.swing.*;
import java.awt.*;

public class LectureAllocationPanel extends JPanel {

    public LectureAllocationPanel(MainFrame frame) {

        setLayout(new GridBagLayout());
        setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12,12,12,12);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(new Color(20, 22, 45, 200));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255,255,255,40)),
                BorderFactory.createEmptyBorder(30,40,30,40)
        ));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10,10,10,10);
        c.fill = GridBagConstraints.HORIZONTAL;


        JLabel title = new JLabel("Lecture Allocation", JLabel.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        card.add(title, c);

        c.gridwidth = 1;

        LectureAllocationController controller = new LectureAllocationController();

        JComboBox<String> cmbLecturer = styledCombo();
        JComboBox<String> cmbCourse   = styledCombo();
        JComboBox<String> cmbDay      = styledCombo(new String[]{"Monday","Tuesday","Wednesday","Thursday","Friday"});
        JComboBox<String> cmbTime     = styledCombo(new String[]{"8.30-10.30","10.30-12.30","1.30-3.30"});

        controller.getLecturers().forEach(cmbLecturer::addItem);
        controller.getCourses().forEach(cmbCourse::addItem);

        addRow(card, c, 1, "Lecturer", cmbLecturer);
        addRow(card, c, 2, "Course", cmbCourse);
        addRow(card, c, 3, "Day", cmbDay);
        addRow(card, c, 4, "Time", cmbTime);


        JButton btnBack = neonButton("Back");
        c.gridx = 0; c.gridy = 5;
        card.add(btnBack, c);

        JButton btnSave = neonButton("Allocate");
        c.gridx = 1;
        card.add(btnSave, c);

        add(card, gbc);


        btnBack.addActionListener(e ->
                frame.cardLayout.show(frame.contentPanel, "DASHBOARD")
        );


        btnSave.addActionListener(e -> {
            LectureAllocation la = new LectureAllocation(
                    cmbLecturer.getSelectedItem().toString(),
                    cmbCourse.getSelectedItem().toString(),
                    cmbDay.getSelectedItem().toString(),
                    cmbTime.getSelectedItem().toString()
            );

            if (controller.save(la)) {
                JOptionPane.showMessageDialog(this, "Lecture Allocated Successfully");
            } else {
                JOptionPane.showMessageDialog(this, "Error!", "DB Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }


    private void addRow(JPanel panel, GridBagConstraints c, int y, String text, JComponent field){
        JLabel lbl = new JLabel(text);
        lbl.setForeground(new Color(180,180,255));
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        c.gridx = 0; c.gridy = y;
        panel.add(lbl, c);

        c.gridx = 1;
        panel.add(field, c);
    }


    private JComboBox<String> styledCombo() {
        return styledCombo(new String[]{});
    }

    private JComboBox<String> styledCombo(String[] items) {
        JComboBox<String> cmb = new JComboBox<>(items);
        cmb.setBackground(new Color(30,32,60));
        cmb.setForeground(Color.WHITE);
        cmb.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmb.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120,100,255)),
                BorderFactory.createEmptyBorder(6,10,6,10)
        ));

        cmb.setUI(new javax.swing.plaf.basic.BasicComboBoxUI() {
            protected JButton createArrowButton() {
                JButton btn = new JButton("▼");
                btn.setBackground(new Color(110,80,255));
                btn.setForeground(Color.WHITE);
                btn.setBorder(BorderFactory.createEmptyBorder());
                return btn;
            }
        });

        return cmb;
    }


    private JButton neonButton(String text){
        JButton btn = new JButton(text);
        btn.setBackground(new Color(110,80,255));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(160,90,255));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(110,80,255));
            }
        });
        return btn;
    }
}
