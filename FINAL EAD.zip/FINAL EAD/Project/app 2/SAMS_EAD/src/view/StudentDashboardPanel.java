package view;

import controller.AttendanceController;
import controller.AssessmentController;
import controller.StudentController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Map;

public class StudentDashboardPanel extends JPanel {

    private final MainFrame frame;

    private float gradientShift = 0f;


    private JLabel lblTotal;
    private JLabel lblSubText;

    private MiniBarChart barChart;
    private CircleProgress circle;

    public StudentDashboardPanel(MainFrame frame) {
        this.frame = frame;

        setLayout(new BorderLayout());
        setOpaque(false);

        startGradientAnimation();

        JLabel title = new JLabel("Student Dashboard");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setBorder(BorderFactory.createEmptyBorder(28, 40, 10, 0));
        add(title, BorderLayout.NORTH);


        JPanel actionPanel = new JPanel(new GridLayout(1, 3, 35, 35));
        actionPanel.setOpaque(false);
        actionPanel.setBorder(BorderFactory.createEmptyBorder(25, 60, 20, 60));

        actionPanel.add(navCard("👤", "Manage Students", "Add / Edit / View",
                () -> frame.cardLayout.show(frame.contentPanel, "STUDENT")));

        actionPanel.add(navCard("📊", "Assessment Results", "Enter / View Results",
                () -> frame.cardLayout.show(frame.contentPanel, "ASSESSMENT")));

        actionPanel.add(navCard("⏰", "Attendance", "Mark / View Percentage",
                () -> frame.cardLayout.show(frame.contentPanel, "ATTENDANCE")));

        add(actionPanel, BorderLayout.CENTER);


        JPanel statsRow = new JPanel(new GridLayout(1, 2, 35, 35));
        statsRow.setOpaque(false);
        statsRow.setBorder(BorderFactory.createEmptyBorder(0, 60, 30, 60));

        statsRow.add(createLeftStatsCard());
        statsRow.add(createRightStatsCard());

        add(statsRow, BorderLayout.SOUTH);


        loadDashboardData();
    }


    private JPanel createLeftStatsCard() {
        RoundedPanel card = glassCard();

        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(22, 22, 22, 22));

        JLabel icon = new JLabel("👥");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
        icon.setForeground(Color.WHITE);

        JLabel t = new JLabel("Total Students (Live)");
        t.setForeground(Color.WHITE);
        t.setFont(new Font("Segoe UI", Font.BOLD, 16));

        lblTotal = new JLabel("0");
        lblTotal.setForeground(new Color(215, 195, 255));
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 52));

        lblSubText = new JLabel("Loading...");
        lblSubText.setForeground(new Color(220, 220, 255));
        lblSubText.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        card.add(icon);
        card.add(Box.createVerticalStrut(12));
        card.add(t);
        card.add(Box.createVerticalStrut(10));
        card.add(lblTotal);
        card.add(Box.createVerticalStrut(6));
        card.add(lblSubText);

        return card;
    }


    private JPanel createRightStatsCard() {
        RoundedPanel card = glassCard();
        card.setLayout(new BorderLayout(12, 12));
        card.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));

        JLabel title = new JLabel("Quick Insights");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        card.add(title, BorderLayout.NORTH);

        JPanel center = new JPanel(new GridLayout(1, 2, 18, 18));
        center.setOpaque(false);

        barChart = new MiniBarChart();
        barChart.setOpaque(false);

        JPanel right = new JPanel(new GridBagLayout());
        right.setOpaque(false);

        circle = new CircleProgress();
        circle.setPreferredSize(new Dimension(150, 150));

        JLabel attLbl = new JLabel("Overall Attendance");
        attLbl.setForeground(new Color(220, 220, 255));
        attLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.gridx = 0; c.gridy = 0;
        right.add(circle, c);
        c.gridy = 1;
        right.add(attLbl, c);

        center.add(barChart);
        center.add(right);

        card.add(center, BorderLayout.CENTER);

        return card;
    }


    private void loadDashboardData() {

        StudentController studentController = new StudentController();
        AssessmentController assessmentController = new AssessmentController();
        AttendanceController attendanceController = new AttendanceController();

        int studentCount = studentController.getStudentCount();
        Map<String, Integer> topAvg = assessmentController.getTopCourseAverages();
        double overallAttendance = attendanceController.getOverallAttendancePercentage();


        animateCount(lblTotal, studentCount);
        lblSubText.setText("Database: sams_db • students table");


        barChart.setData(topAvg);

        circle.setValue(overallAttendance);
    }

    private void animateCount(JLabel label, int target) {
        final int[] val = {0};
        Timer timer = new Timer(15, null);
        timer.addActionListener((ActionEvent e) -> {
            if (val[0] < target) {
                val[0] += Math.max(1, target / 80); // smooth speed
                if (val[0] > target) val[0] = target;
                label.setText(String.valueOf(val[0]));
            } else {
                timer.stop();
            }
        });
        timer.start();
    }


    private JPanel navCard(String icon, String title, String subtitle, Runnable action) {
        RoundedPanel card = new RoundedPanel(25, new Color(255, 255, 255, 45));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(26, 26, 26, 26));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel ic = new JLabel(icon);
        ic.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
        ic.setForeground(new Color(235, 225, 255));

        JLabel t = new JLabel(title);
        t.setForeground(Color.WHITE);
        t.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JLabel s = new JLabel(subtitle);
        s.setForeground(new Color(220, 220, 255));
        s.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        card.add(ic);
        card.add(Box.createVerticalStrut(16));
        card.add(t);
        card.add(Box.createVerticalStrut(6));
        card.add(s);

        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                card.setBackground(new Color(255, 255, 255, 65));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                card.setBackground(new Color(255, 255, 255, 45));
            }
            public void mouseClicked(java.awt.event.MouseEvent e) {
                action.run();
            }
        });

        return card;
    }

    private RoundedPanel glassCard() {
        return new RoundedPanel(25, new Color(255, 255, 255, 35));
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        int w = getWidth();
        int h = getHeight();

        GradientPaint gp = new GradientPaint(
                0, h * gradientShift, new Color(35, 30, 85),
                w, h, new Color(125, 75, 255)
        );

        g2.setPaint(gp);
        g2.fillRect(0, 0, w, h);
    }

    private void startGradientAnimation() {
        Timer timer = new Timer(40, (ActionEvent e) -> {
            gradientShift += 0.01f;
            if (gradientShift > 1f) gradientShift = 0f;
            repaint();
        });
        timer.start();
    }


    static class MiniBarChart extends JPanel {
        private Map<String, Integer> data;

        public void setData(Map<String, Integer> data) {
            this.data = data;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g;
            g2.setFont(new Font("Segoe UI", Font.BOLD, 12));

            if (data == null || data.isEmpty()) {
                g2.setColor(Color.WHITE);
                g2.drawString("No assessment data yet", 10, 25);
                return;
            }

            int w = getWidth();
            int h = getHeight();

            g2.setColor(new Color(230, 230, 255));
            g2.drawString("Top Course Avg Marks", 10, 18);

            int left = 10, bottom = h - 20;
            int barMaxH = h - 50;

            int n = data.size();
            int barW = Math.max(18, (w - 40) / (n * 2));
            int x = left + 10;

            for (Map.Entry<String, Integer> e : data.entrySet()) {
                int val = Math.max(0, Math.min(100, e.getValue()));
                int barH = (int) (barMaxH * (val / 100.0));
                int y = bottom - barH;

                g2.setColor(new Color(120, 90, 255));
                g2.fillRoundRect(x, y, barW, barH, 10, 10);

                g2.setColor(Color.WHITE);
                g2.drawString(String.valueOf(val), x, y - 6);

                g2.setColor(new Color(220, 220, 255));
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                String label = e.getKey();
                if (label.length() > 8) label = label.substring(0, 8) + "...";
                g2.drawString(label, x, bottom + 14);

                x += barW + 18;
            }
        }
    }


    static class CircleProgress extends JPanel {
        private double value = 0.0; // 0..100

        public void setValue(double v) {
            value = Math.max(0, Math.min(100, v));
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int size = Math.min(getWidth(), getHeight()) - 10;
            int x = (getWidth() - size) / 2;
            int y = (getHeight() - size) / 2;


            g2.setStroke(new BasicStroke(12f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(255, 255, 255, 60));
            g2.drawArc(x, y, size, size, 90, -360);


            g2.setColor(new Color(120, 90, 255));
            int angle = (int) Math.round((value / 100.0) * 360);
            g2.drawArc(x, y, size, size, 90, -angle);


            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 18));
            String txt = String.format("%.1f%%", value);

            FontMetrics fm = g2.getFontMetrics();
            int tx = getWidth() / 2 - fm.stringWidth(txt) / 2;
            int ty = getHeight() / 2 + fm.getAscent() / 2 - 2;

            g2.drawString(txt, tx, ty);
        }
    }
}
