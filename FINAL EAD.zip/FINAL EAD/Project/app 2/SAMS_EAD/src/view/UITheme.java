package view;

import javax.swing.*;
import java.awt.*;

public class UITheme {


    public static final Color BACKGROUND = new Color(18, 18, 32);
    public static final Color CARD = new Color(28, 28, 48);
    public static final Color ACCENT = new Color(120, 80, 255);
    public static final Color HOVER = new Color(40, 40, 70);
    public static final Color TEXT = Color.WHITE;
    public static final Color SUBTEXT = new Color(170, 170, 200);

    public static void styleCard(JPanel panel) {
        panel.setBackground(CARD);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60,60,90)),
                BorderFactory.createEmptyBorder(25, 30, 25, 30)
        ));
    }


    public static void styleButton(JButton btn) {
        btn.setBackground(ACCENT);
        btn.setForeground(TEXT);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(150, 110, 255));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(ACCENT);
            }
        });
    }


    public static void styleField(JTextField tf) {
        tf.setBackground(new Color(35,35,60));
        tf.setForeground(TEXT);
        tf.setCaretColor(TEXT);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(70,70,110)),
                BorderFactory.createEmptyBorder(8,12,8,12)
        ));
    }


    public static void styleCombo(JComboBox<?> cb) {
        cb.setBackground(new Color(35,35,60));
        cb.setForeground(TEXT);
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cb.setBorder(BorderFactory.createLineBorder(new Color(70,70,110)));
    }
}
