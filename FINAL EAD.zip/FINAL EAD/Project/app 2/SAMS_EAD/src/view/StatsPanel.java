package view;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;

public class StatsPanel extends JPanel {

    public StatsPanel() {

        setLayout(new BorderLayout());
        setOpaque(false);


        JPanel card = new JPanel(new BorderLayout());
        card.setOpaque(true);
        card.setBackground(new Color(22, 22, 45));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120, 80, 255, 80)),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)
        ));

        JLabel title = new JLabel("System Statistics");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(0, 4, 12, 0));
        card.add(title, BorderLayout.NORTH);

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(120, "Count", "Students");
        dataset.addValue(12, "Count", "Courses");
        dataset.addValue(8, "Count", "Lecturers");

        JFreeChart chart = ChartFactory.createBarChart(
                "",                     // chart title handled by JLabel
                "Category",
                "Count",
                dataset,
                PlotOrientation.VERTICAL,
                false,
                true,
                false
        );


        chart.setBackgroundPaint(new Color(22, 22, 45));
        if (chart.getTitle() != null) {
            chart.getTitle().setPaint(Color.WHITE);
            chart.getTitle().setFont(new Font("Segoe UI", Font.BOLD, 18));
        }

        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(new Color(18, 18, 32));
        plot.setOutlineVisible(false);
        plot.setDomainGridlinePaint(new Color(255, 255, 255, 40));
        plot.setRangeGridlinePaint(new Color(255, 255, 255, 40));


        plot.getDomainAxis().setLabelPaint(new Color(200, 200, 230));
        plot.getDomainAxis().setTickLabelPaint(Color.WHITE);
        plot.getDomainAxis().setLabelFont(new Font("Segoe UI", Font.PLAIN, 13));
        plot.getDomainAxis().setTickLabelFont(new Font("Segoe UI", Font.PLAIN, 13));

        plot.getRangeAxis().setLabelPaint(new Color(200, 200, 230));
        plot.getRangeAxis().setTickLabelPaint(Color.WHITE);
        plot.getRangeAxis().setLabelFont(new Font("Segoe UI", Font.PLAIN, 13));
        plot.getRangeAxis().setTickLabelFont(new Font("Segoe UI", Font.PLAIN, 13));


        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setBarPainter(new org.jfree.chart.renderer.category.StandardBarPainter());
        renderer.setDrawBarOutline(false);


        renderer.setSeriesPaint(0, new Color(120, 80, 255));


        renderer.setItemMargin(0.15);


        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setOpaque(false);
        chartPanel.setBackground(new Color(0,0,0,0));
        chartPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        chartPanel.setPopupMenu(null); // optional: remove right click menu

        card.add(chartPanel, BorderLayout.CENTER);
        add(card, BorderLayout.CENTER);
    }
}
