package view;

import javax.swing.*;
import java.awt.*;

public class LoginPanel extends JPanel {

    private float glowPhase = 0f;

    public LoginPanel(MainFrame frame) {

        setLayout(new GridBagLayout());
        setOpaque(false);

        JPanel card = new JPanel(new GridBagLayout());
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(500, 500));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(15,15,15,15);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Welcome to StudentX");
        title.setFont(new Font("Segoe UI", Font.BOLD, 42));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        c.gridx=0; c.gridy=0; c.gridwidth=2;
        card.add(title,c);
        c.gridwidth=1;

        JTextField txtUser = neonField();
        JPasswordField txtPass = new JPasswordField();
        styleNeonField(txtPass);

        JComboBox<String> cmbRole = new JComboBox<>(new String[]{"Admin","Student"});
        styleCombo(cmbRole);

        addRow(card,c,1,"Username",txtUser);
        addRow(card,c,2,"Password",txtPass);
        addRow(card,c,3,"Role",cmbRole);

        JButton btnLogin = neonButton("ACCESS SYSTEM");
        c.gridx=0; c.gridy=4; c.gridwidth=2;
        card.add(btnLogin,c);

        add(card);


        btnLogin.addActionListener(e -> {
            frame.sidebar.showCollapsed();

            String role = (String)cmbRole.getSelectedItem();
            if("Admin".equals(role))
                frame.cardLayout.show(frame.contentPanel,"DASHBOARD");
            else
                frame.cardLayout.show(frame.contentPanel,"STUDENT_DASHBOARD");
        });

        startGlowAnimation(title);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        GradientPaint gp = new GradientPaint(
                0,0,new Color(5,5,20),
                getWidth(),getHeight(),new Color(50,0,90)
        );

        g2.setPaint(gp);
        g2.fillRect(0,0,getWidth(),getHeight());
    }


    private void startGlowAnimation(JLabel title){

        Timer timer = new Timer(40, e -> {
            glowPhase += 0.05f;
            float intensity = (float)(Math.sin(glowPhase)+1)/2;

            int glow = (int)(150 + 105*intensity);
            title.setForeground(new Color(glow, 0, 255));
        });

        timer.start();
    }


    private void addRow(JPanel panel, GridBagConstraints c, int y, String text, JComponent field){

        JLabel lbl = new JLabel(text);
        lbl.setForeground(new Color(0,255,200));
        lbl.setFont(new Font("Segoe UI",Font.PLAIN,14));

        c.gridx=0; c.gridy=y;
        panel.add(lbl,c);

        c.gridx=1;
        panel.add(field,c);
    }


    private JTextField neonField(){
        JTextField tf = new JTextField();
        styleNeonField(tf);
        return tf;
    }

    private void styleNeonField(JTextField tf){
        tf.setBackground(new Color(10,10,30));
        tf.setForeground(Color.WHITE);
        tf.setCaretColor(new Color(0,255,200));
        tf.setFont(new Font("Segoe UI",Font.PLAIN,14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0,255,200)),
                BorderFactory.createEmptyBorder(10,15,10,15)
        ));
    }

    private void styleCombo(JComboBox<String> cmb){
        cmb.setBackground(new Color(10,10,30));
        cmb.setForeground(Color.WHITE);
        cmb.setFont(new Font("Segoe UI",Font.PLAIN,14));
        cmb.setBorder(BorderFactory.createLineBorder(new Color(255,0,255)));
    }


    private JButton neonButton(String text){

        JButton btn = new JButton(text);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI",Font.BOLD,16));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(14,25,14,25));

        Timer pulse = new Timer(40,null);

        pulse.addActionListener(e->{
            float phase = (float)(Math.sin(System.currentTimeMillis()/300.0)+1)/2;
            int r = (int)(100 + 155*phase);
            btn.setBackground(new Color(r,0,255));
        });

        pulse.start();

        return btn;
    }
}
