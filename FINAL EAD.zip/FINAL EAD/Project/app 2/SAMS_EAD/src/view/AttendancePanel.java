package view;

import controller.AttendanceController;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AttendancePanel extends JPanel {

    public AttendancePanel() {
        setLayout(new GridBagLayout());
        setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        AttendanceController controller = new AttendanceController();


        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(new Color(20, 22, 45, 200));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 255, 255, 40)),
                BorderFactory.createEmptyBorder(30, 40, 30, 40)
        ));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.fill = GridBagConstraints.HORIZONTAL;


        JLabel title = new JLabel("Attendance", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        card.add(title, c);
        c.gridwidth = 1;


        JLabel lblStudent = createLabel("Student");
        c.gridx = 0; c.gridy = 1;
        card.add(lblStudent, c);

        JComboBox<String> cmbStudent = new JComboBox<>();
        cmbStudent.addItem("-- Select Student --");
        List<String> students = controller.getStudents();
        for (String s : students) cmbStudent.addItem(s);
        styleCombo(cmbStudent);
        c.gridx = 1;
        card.add(cmbStudent, c);


        JLabel lblCourse = createLabel("Course");
        c.gridx = 0; c.gridy = 2;
        card.add(lblCourse, c);

        JComboBox<String> cmbCourse = new JComboBox<>();
        cmbCourse.addItem("-- Select Course --");
        List<String> courses = controller.getCourses();
        for (String co : courses) cmbCourse.addItem(co);
        styleCombo(cmbCourse);
        c.gridx = 1;
        card.add(cmbCourse, c);


        JLabel lblStatus = createLabel("Status");
        c.gridx = 0; c.gridy = 3;
        card.add(lblStatus, c);

        JComboBox<String> cmbStatus = new JComboBox<>(new String[]{"Present", "Absent"});
        styleCombo(cmbStatus);
        c.gridx = 1;
        card.add(cmbStatus, c);


        JButton btnSave = neonButton("Save Attendance");
        c.gridx = 1; c.gridy = 4;
        card.add(btnSave, c);


        btnSave.addActionListener(e -> {
            String student = (String) cmbStudent.getSelectedItem();
            String course = (String) cmbCourse.getSelectedItem();
            String status = (String) cmbStatus.getSelectedItem();

            if(student == null || course == null || student.equals("-- Select Student --") || course.equals("-- Select Course --")){
                JOptionPane.showMessageDialog(this,
                        "Please select Student and Course",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // TODO: call controller.saveAttendance(student, course, status);
            JOptionPane.showMessageDialog(this,
                    "Attendance saved:\n" +
                            "Student: " + student + "\n" +
                            "Course: " + course + "\n" +
                            "Status: " + status,
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(card, gbc);
    }


    private JLabel createLabel(String text){
        JLabel lbl = new JLabel(text);
        lbl.setForeground(Color.LIGHT_GRAY);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return lbl;
    }


    private void styleCombo(JComboBox<String> combo){
        combo.setBackground(new Color(30, 32, 60));
        combo.setForeground(Color.WHITE);
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        combo.setBorder(BorderFactory.createLineBorder(new Color(120, 100, 255)));
    }


    private JButton neonButton(String text){
        JButton btn = new JButton(text);
        btn.setBackground(new Color(110, 80, 255));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(new Color(160, 90, 255)); }
            public void mouseExited(java.awt.event.MouseEvent e) { btn.setBackground(new Color(110, 80, 255)); }
        });
        return btn;
    }
}
