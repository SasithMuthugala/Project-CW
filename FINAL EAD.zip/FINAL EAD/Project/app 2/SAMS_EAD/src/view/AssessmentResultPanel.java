package view;

import controller.AssessmentController;
import model.AssessmentResult;
import model.Item;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class AssessmentResultPanel extends JPanel {

    private JComboBox<Item> cmbStudent;
    private JComboBox<Item> cmbCourse;
    private JTextField txtMarks, txtGrade;

    private ChartPanel chartPanel;

    private MainFrame frame;

    public AssessmentResultPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(20,22,45));
        setOpaque(true);

        AssessmentController controller = new AssessmentController();


        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        form.setBorder(BorderFactory.createEmptyBorder(20,40,20,40));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10,10,10,10);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Assessment Result Entry", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        c.gridx=0; c.gridy=0; c.gridwidth=2;
        form.add(title,c);
        c.gridwidth=1;

        cmbStudent = new JComboBox<>();
        reloadStudents();
        addRow(form,c,1,"Student",cmbStudent);

        cmbCourse = new JComboBox<>();
        reloadCourses();
        addRow(form,c,2,"Course",cmbCourse);

        txtMarks = field();
        addRow(form,c,3,"Marks",txtMarks);

        txtGrade = field();
        addRow(form,c,4,"Grade",txtGrade);

        JButton btnSave = neonButton("Save Result");
        c.gridx=0; c.gridy=5;
        form.add(btnSave,c);

        JButton btnViewChart = neonButton("View Performance");
        c.gridx=1;
        form.add(btnViewChart,c);

        add(form,BorderLayout.NORTH);

        // ===== CHART PANEL =====
        chartPanel = new ChartPanel();
        chartPanel.setBackground(new Color(20,22,45));
        add(chartPanel,BorderLayout.CENTER);

        // ===== SAVE ACTION =====
        btnSave.addActionListener(e -> {

            Item studentItem = (Item)cmbStudent.getSelectedItem();
            Item courseItem  = (Item)cmbCourse.getSelectedItem();

            if(studentItem==null || courseItem==null ||
                    studentItem.id==0 || courseItem.id==0 ||
                    txtMarks.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(this,"All fields required");
                return;
            }

            int marks;
            try { marks = Integer.parseInt(txtMarks.getText().trim()); }
            catch(Exception ex){
                JOptionPane.showMessageDialog(this,"Marks must be number");
                return;
            }

            AssessmentResult result = new AssessmentResult(
                    studentItem.id,
                    courseItem.id,
                    marks,
                    txtGrade.getText().trim()
            );

            if(controller.saveResult(result)){
                JOptionPane.showMessageDialog(this,"Saved!");
                txtMarks.setText("");
                txtGrade.setText("");
            } else {
                JOptionPane.showMessageDialog(this,"DB Error");
            }
        });


        btnViewChart.addActionListener(e -> {

            Item studentItem = (Item)cmbStudent.getSelectedItem();

            if(studentItem==null || studentItem.id==0){
                JOptionPane.showMessageDialog(this,"Select student first!");
                return;
            }

            Map<String,Integer> data =
                    controller.getMarksByStudentId(studentItem.id);

            chartPanel.setData(data);
        });
    }


    public void reloadStudents(){
        cmbStudent.removeAllItems();
        cmbStudent.addItem(new Item(0,"-- Select Student --"));
        AssessmentController controller = new AssessmentController();

        for(Map.Entry<Integer,String> entry :
                controller.getStudentsMap().entrySet()){
            cmbStudent.addItem(new Item(entry.getKey(), entry.getValue()));
        }
    }

    public void reloadCourses(){
        cmbCourse.removeAllItems();
        cmbCourse.addItem(new Item(0,"-- Select Course --"));
        AssessmentController controller = new AssessmentController();

        for(Map.Entry<Integer,String> entry :
                controller.getCoursesMap().entrySet()){
            cmbCourse.addItem(new Item(entry.getKey(), entry.getValue()));
        }
    }


    private void addRow(JPanel panel, GridBagConstraints c,
                        int y, String text, JComponent field){

        JLabel lbl = new JLabel(text);
        lbl.setForeground(new Color(180,180,255));
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        c.gridx=0; c.gridy=y;
        panel.add(lbl,c);

        c.gridx=1;
        panel.add(field,c);
    }

    private JTextField field(){
        JTextField tf = new JTextField();
        tf.setBackground(new Color(30,32,60));
        tf.setForeground(Color.WHITE);
        tf.setCaretColor(Color.WHITE);
        tf.setBorder(BorderFactory.createLineBorder(
                new Color(120,100,255)));
        return tf;
    }

    private JButton neonButton(String text){
        JButton btn = new JButton(text);
        btn.setBackground(new Color(110,80,255));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(160,90,255));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(110,80,255));
            }
        });
        return btn;
    }


    static class ChartPanel extends JPanel {

        private Map<String,Integer> data;

        public void setData(Map<String,Integer> data){
            this.data=data;
            repaint();
        }

        protected void paintComponent(Graphics g){
            super.paintComponent(g);

            if(data==null || data.isEmpty()){
                g.setColor(Color.WHITE);
                g.drawString("No data to display",50,50);
                return;
            }

            int width=getWidth();
            int height=getHeight();

            int barWidth=50;
            int gap=40;
            int x=80;

            for(Map.Entry<String,Integer> entry : data.entrySet()){

                int value=entry.getValue();
                int barHeight=(int)(value*2);

                g.setColor(new Color(120,90,255));
                g.fillRect(x,height-barHeight-80,barWidth,barHeight);

                g.setColor(Color.WHITE);
                g.drawString(entry.getKey(),x,height-60);
                g.drawString(String.valueOf(value),
                        x,height-barHeight-90);

                x+=barWidth+gap;
            }
        }
    }
}
