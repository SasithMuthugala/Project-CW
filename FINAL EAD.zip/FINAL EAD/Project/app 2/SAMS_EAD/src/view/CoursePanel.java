package view;

import controller.CourseController;
import model.Course;

import javax.swing.*;
import java.awt.*;

public class CoursePanel extends JPanel {

    public CoursePanel(MainFrame frame) {


        setOpaque(false);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        JPanel card = new JPanel(new GridBagLayout());
        card.setOpaque(true);
        card.setBackground(new Color(20, 22, 45)); // solid (no alpha) - stable
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120, 80, 255, 90)), // soft violet
                BorderFactory.createEmptyBorder(30, 40, 30, 40)
        ));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Course Registration", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        card.add(title, c);
        c.gridwidth = 1;


        JLabel lblName = label("Course Name");
        c.gridx = 0; c.gridy = 1;
        card.add(lblName, c);

        JTextField txtCourseName = field();
        c.gridx = 1;
        card.add(txtCourseName, c);

        JLabel lblCode = label("Course Code");
        c.gridx = 0; c.gridy = 2;
        card.add(lblCode, c);

        JTextField txtCourseCode = field();
        c.gridx = 1;
        card.add(txtCourseCode, c);


        JButton btnBack = modernButton("Back");
        c.gridx = 0; c.gridy = 3;
        card.add(btnBack, c);

        JButton btnSave = modernButton("Save Course");
        c.gridx = 1;
        card.add(btnSave, c);

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(card, gbc);


        btnBack.addActionListener(e ->
                frame.cardLayout.show(frame.contentPanel, "DASHBOARD")
        );

        CourseController controller = new CourseController();

        btnSave.addActionListener(e -> {

            String name = txtCourseName.getText().trim();
            String code = txtCourseCode.getText().trim();

            if (name.isEmpty() || code.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "All fields are required",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            Course course = new Course(name, code);

            if (controller.saveCourse(course)) {

                JOptionPane.showMessageDialog(this,
                        "Course saved: " + name + " (" + code + ")",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);

                txtCourseName.setText("");
                txtCourseCode.setText("");


                for (Component comp : frame.contentPanel.getComponents()) {
                    if (comp instanceof AssessmentResultPanel arp) {
                        arp.reloadCourses();
                        break;
                    }
                }

            } else {
                JOptionPane.showMessageDialog(this,
                        "Database error",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
    }


    private JLabel label(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(new Color(180, 180, 220));
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return lbl;
    }

    private JTextField field() {
        JTextField tf = new JTextField();
        tf.setBackground(new Color(32, 32, 55));
        tf.setForeground(Color.WHITE);
        tf.setCaretColor(Color.WHITE);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120, 80, 255, 90)),
                BorderFactory.createEmptyBorder(9, 12, 9, 12)
        ));
        return tf;
    }

    private JButton modernButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(120, 80, 255));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(150, 110, 255));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(120, 80, 255));
            }
        });

        return btn;
    }
}
