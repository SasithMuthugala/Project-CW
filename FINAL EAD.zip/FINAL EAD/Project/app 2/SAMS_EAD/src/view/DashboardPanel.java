package view;

import controller.ReportController;
import controller.AttendanceReportController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class DashboardPanel extends JPanel {

    private final MainFrame frame;
    private float gradientShift = 0f;

    public DashboardPanel(MainFrame frame) {
        this.frame = frame;

        setLayout(new BorderLayout());
        setOpaque(false);

        startGradientAnimation();


        JLabel title = new JLabel("Overview");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 30));
        title.setBorder(BorderFactory.createEmptyBorder(35, 50, 20, 0));
        add(title, BorderLayout.NORTH);


        JPanel cards = new JPanel(new GridLayout(1, 4, 30, 30));
        cards.setOpaque(false);
        cards.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        cards.add(createAnimatedCard("Students", "120", "ACTIVE", "👤"));
        cards.add(createAnimatedCard("Courses", "12", "RUNNING", "📚"));
        cards.add(createAnimatedCard("Lecturers", "8", "AVAILABLE", "🎓"));
        cards.add(createAnimatedCard("Attendance", "50%", "TODAY", "⏰"));

        add(cards, BorderLayout.CENTER);


        JPanel bottomPanel = new JPanel(new GridLayout(2, 3, 20, 20));
        bottomPanel.setOpaque(false);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 100, 35, 100));

        JButton btnStudentDashboard = modernButton("Student Dashboard");
        btnStudentDashboard.addActionListener(e ->
                frame.cardLayout.show(frame.contentPanel, "STUDENT_DASHBOARD")
        );

        JButton btnCourse = modernButton("Courses");
        btnCourse.addActionListener(e ->
                frame.cardLayout.show(frame.contentPanel, "COURSE")
        );

        JButton btnLecture = modernButton("Lecture Allocation");
        btnLecture.addActionListener(e ->
                frame.cardLayout.show(frame.contentPanel, "LECTURE")
        );

        JButton btnStudentReport = modernButton("Student Report");
        btnStudentReport.addActionListener(e ->
                new ReportController().showJasperReport()
        );


        JButton btnAttendanceReport = modernButton("Attendance Report");
        btnAttendanceReport.addActionListener(e ->
                new AttendanceReportController().showAttendanceReport()
        );

        JButton btnAssessment = modernButton("Assessment Results");
        btnAssessment.addActionListener(e ->
                frame.cardLayout.show(frame.contentPanel, "ASSESSMENT")
        );

        bottomPanel.add(btnStudentDashboard);
        bottomPanel.add(btnCourse);
        bottomPanel.add(btnLecture);
        bottomPanel.add(btnStudentReport);
        bottomPanel.add(btnAttendanceReport);
        bottomPanel.add(btnAssessment);

        add(bottomPanel, BorderLayout.SOUTH);
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        int width = getWidth();
        int height = getHeight();

        float shift = gradientShift;

        GradientPaint gp = new GradientPaint(
                0, height * shift, new Color(25, 28, 55),
                width, height,     new Color(70, 40, 130)
        );

        g2.setPaint(gp);
        g2.fillRect(0, 0, width, height);
    }

    private void startGradientAnimation() {
        Timer timer = new Timer(40, (ActionEvent e) -> {
            gradientShift += 0.01f;
            if (gradientShift > 1f) gradientShift = 0f;
            repaint();
        });
        timer.start();
    }


    private JPanel createAnimatedCard(String title, String value, String sub, String icon) {

        RoundedPanel card = new RoundedPanel(25, new Color(40, 45, 90, 200));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel lblIcon = new JLabel(icon);
        lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 30));
        lblIcon.setForeground(new Color(200, 170, 255));

        JLabel t = new JLabel(title);
        t.setForeground(Color.LIGHT_GRAY);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 15));

        JLabel v = new JLabel(value);
        v.setForeground(Color.WHITE);
        v.setFont(new Font("Segoe UI", Font.BOLD, 34));

        JLabel s = new JLabel(sub);
        s.setForeground(new Color(180, 160, 255));
        s.setFont(new Font("Segoe UI", Font.BOLD, 13));

        card.add(lblIcon);
        card.add(Box.createVerticalStrut(15));
        card.add(t);
        card.add(Box.createVerticalStrut(10));
        card.add(v);
        card.add(Box.createVerticalStrut(8));
        card.add(s);


        final float[] scale = {1.0f};
        Timer hoverTimer = new Timer(15, null);

        hoverTimer.addActionListener(e -> {
            boolean hover = Boolean.TRUE.equals(card.getClientProperty("hover"));

            if (hover) {
                if (scale[0] < 1.08f) scale[0] += 0.02f;
            } else {
                if (scale[0] > 1.0f) scale[0] -= 0.02f;
            }


            int pad = (int) (25 * scale[0]);
            card.setBorder(BorderFactory.createEmptyBorder(pad, pad, pad, pad));
            card.revalidate();
            card.repaint();
        });

        hoverTimer.start();

        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                card.putClientProperty("hover", Boolean.TRUE);
                card.setBackground(new Color(65, 70, 140, 230));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                card.putClientProperty("hover", Boolean.FALSE);
                card.setBackground(new Color(40, 45, 90, 200));
            }
        });

        return card;
    }


    private JButton modernButton(String text) {

        JButton btn = new JButton(text);
        btn.setBackground(new Color(140, 90, 255));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(12, 28, 12, 28));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(180, 130, 255));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(140, 90, 255));
            }
        });

        return btn;
    }
}
