package view;

import controller.StudentController;
import model.Student;

import javax.swing.*;
import java.awt.*;

public class StudentPanel extends JPanel {

    public StudentPanel(MainFrame frame) {


        setLayout(new GridBagLayout());
        setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12,12,12,12);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        JPanel card = new JPanel(new GridBagLayout());
        card.setOpaque(true);
        card.setBackground(new Color(22, 22, 45)); // solid dark
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120, 80, 255, 90)),
                BorderFactory.createEmptyBorder(30,35,30,35)
        ));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10,10,10,10);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Student Management", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        card.add(title, c);

        c.gridwidth = 1;

        JTextField txtId = createField(card, c, "Student ID", 1);
        JTextField txtName = createField(card, c, "Name", 2);
        JTextField txtEmail = createField(card, c, "Email", 3);
        JTextField txtAge = createField(card, c, "Age", 4);
        JTextField txtGrade = createField(card, c, "Grade", 5);

        JButton btnBack = modernButton("Back");
        c.gridx = 0; c.gridy = 6;
        card.add(btnBack, c);

        JButton btnSave = modernButton("Save Student");
        c.gridx = 1;
        card.add(btnSave, c);

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(card, gbc);


        btnBack.addActionListener(e ->
                frame.cardLayout.show(frame.contentPanel, "DASHBOARD")
        );

        btnSave.addActionListener(e -> {

            String idText = txtId.getText().trim();
            String name = txtName.getText().trim();
            String email = txtEmail.getText().trim();
            String ageText = txtAge.getText().trim();
            String grade = txtGrade.getText().trim();

            if(idText.isEmpty() || name.isEmpty() || email.isEmpty() ||
                    ageText.isEmpty() || grade.isEmpty()) {

                JOptionPane.showMessageDialog(this,
                        "All fields required",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                int id = Integer.parseInt(idText);
                int age = Integer.parseInt(ageText);

                Student student = new Student(id,name,email,age,grade);
                StudentController controller = new StudentController();

                if(controller.saveStudent(student)) {
                    JOptionPane.showMessageDialog(this,"Saved Successfully");
                    txtId.setText(""); txtName.setText("");
                    txtEmail.setText(""); txtAge.setText("");
                    txtGrade.setText("");
                } else {
                    JOptionPane.showMessageDialog(this,"Database Error");
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this,
                        "ID & Age must be numbers");
            }
        });
    }

    private JTextField createField(JPanel panel,
                                   GridBagConstraints c,
                                   String label,
                                   int y) {

        JLabel lbl = new JLabel(label);
        lbl.setForeground(new Color(180,180,220));
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        JTextField tf = new JTextField();
        tf.setBackground(new Color(32,32,60));
        tf.setForeground(Color.WHITE);
        tf.setCaretColor(Color.WHITE);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120,80,255,90)),
                BorderFactory.createEmptyBorder(8,12,8,12)
        ));

        c.gridx = 0; c.gridy = y;
        panel.add(lbl, c);

        c.gridx = 1;
        panel.add(tf, c);

        return tf;
    }

    private JButton modernButton(String text) {

        JButton btn = new JButton(text);
        btn.setBackground(new Color(120,80,255));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10,18,10,18));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(150,110,255));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(120,80,255));
            }
        });

        return btn;
    }
}
