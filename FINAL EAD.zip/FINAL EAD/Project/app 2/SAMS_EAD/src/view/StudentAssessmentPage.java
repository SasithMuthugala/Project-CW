package view;

import controller.AssessmentController;
import model.AssessmentResult;
import model.Item;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class StudentAssessmentPage extends JPanel {

    private JComboBox<Item> cmbStudent;
    private JComboBox<Item> cmbCourse;
    private JTextField txtMarks, txtGrade;

    private ChartPanel chartPanel;

    private MainFrame frame;

    public StudentAssessmentPage(MainFrame frame) {
        this.frame = frame;

        setLayout(new BorderLayout(0, 14));
        setOpaque(false);

        AssessmentController controller = new AssessmentController();


        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setOpaque(true);
        formCard.setBackground(new Color(22, 22, 45));
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120, 80, 255, 90)),
                BorderFactory.createEmptyBorder(22, 28, 22, 28)
        ));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Assessment Result Entry", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        formCard.add(title, c);
        c.gridwidth = 1;

        cmbStudent = new JComboBox<>();
        styleCombo(cmbStudent);
        reloadStudents();
        addRow(formCard, c, 1, "Student", cmbStudent);

        cmbCourse = new JComboBox<>();
        styleCombo(cmbCourse);
        reloadCourses();
        addRow(formCard, c, 2, "Course", cmbCourse);

        txtMarks = field();
        addRow(formCard, c, 3, "Marks", txtMarks);

        txtGrade = field();
        addRow(formCard, c, 4, "Grade", txtGrade);

        JButton btnSave = modernButton("Save Result");
        c.gridx = 0; c.gridy = 5;
        formCard.add(btnSave, c);

        JButton btnViewChart = modernButton("View Performance");
        c.gridx = 1;
        formCard.add(btnViewChart, c);

        add(formCard, BorderLayout.NORTH);


        JPanel chartCard = new JPanel(new BorderLayout());
        chartCard.setOpaque(true);
        chartCard.setBackground(new Color(22, 22, 45));
        chartCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120, 80, 255, 70)),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)
        ));

        chartPanel = new ChartPanel();
        chartPanel.setOpaque(false); // paint inside
        chartCard.add(chartPanel, BorderLayout.CENTER);

        add(chartCard, BorderLayout.CENTER);


        btnSave.addActionListener(e -> {

            Item studentItem = (Item) cmbStudent.getSelectedItem();
            Item courseItem  = (Item) cmbCourse.getSelectedItem();

            if (studentItem == null || courseItem == null ||
                    studentItem.id == 0 || courseItem.id == 0 ||
                    txtMarks.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(this, "All fields required");
                return;
            }

            int marks;
            try { marks = Integer.parseInt(txtMarks.getText().trim()); }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Marks must be number");
                return;
            }

            AssessmentResult result = new AssessmentResult(
                    studentItem.id,
                    courseItem.id,
                    marks,
                    txtGrade.getText().trim()
            );

            if (controller.saveResult(result)) {
                JOptionPane.showMessageDialog(this, "Saved!");
                txtMarks.setText("");
                txtGrade.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "DB Error");
            }
        });


        btnViewChart.addActionListener(e -> {

            Item studentItem = (Item) cmbStudent.getSelectedItem();

            if (studentItem == null || studentItem.id == 0) {
                JOptionPane.showMessageDialog(this, "Select student first!");
                return;
            }

            Map<String, Integer> data =
                    controller.getMarksByStudentId(studentItem.id);

            chartPanel.setData(data);
        });
    }


    public void reloadStudents() {
        cmbStudent.removeAllItems();
        cmbStudent.addItem(new Item(0, "-- Select Student --"));
        AssessmentController controller = new AssessmentController();

        for (Map.Entry<Integer, String> entry : controller.getStudentsMap().entrySet()) {
            cmbStudent.addItem(new Item(entry.getKey(), entry.getValue()));
        }
    }

    public void reloadCourses() {
        cmbCourse.removeAllItems();
        cmbCourse.addItem(new Item(0, "-- Select Course --"));
        AssessmentController controller = new AssessmentController();

        for (Map.Entry<Integer, String> entry : controller.getCoursesMap().entrySet()) {
            cmbCourse.addItem(new Item(entry.getKey(), entry.getValue()));
        }
    }


    private void addRow(JPanel panel, GridBagConstraints c,
                        int y, String text, JComponent field) {

        JLabel lbl = new JLabel(text);
        lbl.setForeground(new Color(180, 180, 220));
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        c.gridx = 0; c.gridy = y;
        panel.add(lbl, c);

        c.gridx = 1;
        panel.add(field, c);
    }

    private JTextField field() {
        JTextField tf = new JTextField();
        tf.setBackground(new Color(32, 32, 60));
        tf.setForeground(Color.WHITE);
        tf.setCaretColor(Color.WHITE);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120, 80, 255, 90)),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return tf;
    }

    private void styleCombo(JComboBox<?> cb) {
        cb.setBackground(new Color(32, 32, 60));
        cb.setForeground(Color.WHITE);
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cb.setBorder(BorderFactory.createLineBorder(new Color(120, 80, 255, 70)));
    }

    private JButton modernButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(120, 80, 255));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(150, 110, 255));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(120, 80, 255));
            }
        });
        return btn;
    }


    static class ChartPanel extends JPanel {

        private Map<String, Integer> data;

        public void setData(Map<String, Integer> data) {
            this.data = data;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);


            g2.setColor(new Color(18, 18, 32, 120));
            g2.fillRoundRect(10, 10, getWidth() - 20, getHeight() - 20, 16, 16);

            if (data == null || data.isEmpty()) {
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 16));
                g2.drawString("No data to display", 40, 60);
                return;
            }

            int width = getWidth();
            int height = getHeight();

            int baseY = height - 70;
            int barWidth = 50;
            int gap = 35;
            int x = 60;

            for (Map.Entry<String, Integer> entry : data.entrySet()) {

                int value = entry.getValue();
                int barHeight = Math.min((int) (value * 2.2), height - 140);


                g2.setColor(new Color(120, 80, 255));
                g2.fillRoundRect(x, baseY - barHeight, barWidth, barHeight, 12, 12);


                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                g2.drawString(entry.getKey(), x - 5, baseY + 22);


                g2.setFont(new Font("Segoe UI", Font.BOLD, 13));
                g2.drawString(String.valueOf(value), x + 12, baseY - barHeight - 10);

                x += barWidth + gap;
            }
        }
    }
}
