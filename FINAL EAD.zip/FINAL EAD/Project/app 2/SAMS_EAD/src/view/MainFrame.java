package view;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public CardLayout cardLayout;
    public JPanel contentPanel;
    public SidebarPanel sidebar;

    public MainFrame() {

        setTitle("Kadse25.1f-010 – StudentX app");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);


        GradientRootPanel root = new GradientRootPanel();
        root.setLayout(new BorderLayout());
        setContentPane(root);


        sidebar = new SidebarPanel(this);
        root.add(sidebar, BorderLayout.WEST);


        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setOpaque(false); // important for gradient
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));


        contentPanel.add(new LoginPanel(this), "LOGIN");
        contentPanel.add(new DashboardPanel(this), "DASHBOARD");
        contentPanel.add(new StudentDashboardPanel(this), "STUDENT_DASHBOARD");

        contentPanel.add(new StudentPanel(this), "STUDENT");
        contentPanel.add(new CoursePanel(this), "COURSE");
        contentPanel.add(new LectureAllocationPanel(this), "LECTURE");
        contentPanel.add(new AssessmentResultPanel(this), "ASSESSMENT");
        contentPanel.add(new AttendancePanel(), "ATTENDANCE");
        contentPanel.add(new StatsPanel(), "STATS");

        contentPanel.add(new StudentHomePanel(), "STUDENT_HOME");
        contentPanel.add(new StudentManagementPage(this), "STUDENT_MANAGE");
        contentPanel.add(new StudentAssessmentPage(this), "STUDENT_ASSESS");
        contentPanel.add(new StudentAttendancePage(this), "STUDENT_ATTEND");

        root.add(contentPanel, BorderLayout.CENTER);


        sidebar.hideCompletely();
        cardLayout.show(contentPanel, "LOGIN");
    }


    public void logout() {
        if (sidebar != null) sidebar.hideCompletely();
        cardLayout.show(contentPanel, "LOGIN");
    }


    static class GradientRootPanel extends JPanel {

        private float progress = 0f;
        private final Timer timer;

        public GradientRootPanel() {
            setOpaque(true);

            timer = new Timer(30, e -> {
                progress += 0.003f;  // animation speed
                if (progress > 1f) progress = 0f;
                repaint();
            });

            timer.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                    RenderingHints.VALUE_RENDER_QUALITY);

            int w = getWidth();
            int h = getHeight();

            float wave = (float) (0.5 + 0.5 * Math.sin(progress * 2 * Math.PI));

            Color c1 = blend(
                    new Color(18, 0, 50),
                    new Color(90, 0, 160),
                    wave
            );

            Color c2 = blend(
                    new Color(40, 0, 100),
                    new Color(150, 0, 255),
                    wave
            );

            GradientPaint gp = new GradientPaint(
                    0, 0, c1,
                    w, h, c2
            );

            g2.setPaint(gp);
            g2.fillRect(0, 0, w, h);
        }

        private Color blend(Color a, Color b, float ratio) {

            int r = (int) (a.getRed() + ratio * (b.getRed() - a.getRed()));
            int g = (int) (a.getGreen() + ratio * (b.getGreen() - a.getGreen()));
            int bl = (int) (a.getBlue() + ratio * (b.getBlue() - a.getBlue()));

            return new Color(r, g, bl);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
