package view;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SidebarPanel extends JPanel {

    private final int EXPANDED_WIDTH = 230;
    private final int COLLAPSED_WIDTH = 70;
    private final int HIDDEN_WIDTH = 0;

    private int currentWidth = HIDDEN_WIDTH;

    private Timer slideTimer;
    private Timer closeDelay;


    private final Color bg = new Color(18, 18, 32);
    private final Color borderColor = new Color(120, 80, 255); // soft neon violet
    private final Color hoverColor = new Color(35, 35, 60);

    private final List<JButton> menuButtons = new ArrayList<>();

    public SidebarPanel(MainFrame frame) {

        setOpaque(false);
        setPreferredSize(new Dimension(HIDDEN_WIDTH, 0));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        JLabel logo = new JLabel("  StudentX");
        logo.setForeground(borderColor);
        logo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        logo.setAlignmentX(CENTER_ALIGNMENT);
        logo.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        add(logo);

        add(menuButton("🏠", "Dashboard", () -> frame.cardLayout.show(frame.contentPanel, "DASHBOARD")));
        add(menuButton("👤", "Students", () -> frame.cardLayout.show(frame.contentPanel, "STUDENT")));
        add(menuButton("📚", "Courses", () -> frame.cardLayout.show(frame.contentPanel, "COURSE")));
        add(menuButton("📊", "Assessments", () -> frame.cardLayout.show(frame.contentPanel, "ASSESSMENT")));
        add(menuButton("⏰", "Attendance", () -> frame.cardLayout.show(frame.contentPanel, "ATTENDANCE")));
        add(menuButton("📈", "Stats", () -> frame.cardLayout.show(frame.contentPanel, "STATS")));

        add(Box.createVerticalGlue());
        add(menuButton("🚪", "Logout", frame::logout));

        closeDelay = new Timer(650, e -> {
            if (!isMouseInsideSidebar()) slideOut();
        });
        closeDelay.setRepeats(false);

        installHoverTracking(this);
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;


        g2.setColor(bg);
        g2.fillRect(0, 0, getWidth(), getHeight());


        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(2f));
        g2.drawLine(getWidth() - 1, 0, getWidth() - 1, getHeight());
    }


    public void slideIn() {
        updateButtonText(true);
        slideTo(EXPANDED_WIDTH);
    }

    public void slideOut() {
        updateButtonText(false);
        slideTo(COLLAPSED_WIDTH);
    }

    public void showCollapsed() {
        updateButtonText(false);
        slideTo(COLLAPSED_WIDTH);
    }

    public void hideCompletely() {
        if (slideTimer != null && slideTimer.isRunning()) slideTimer.stop();
        currentWidth = HIDDEN_WIDTH;
        setPreferredSize(new Dimension(HIDDEN_WIDTH, getHeight()));
        revalidate();
        repaint();
    }

    private void slideTo(int target) {

        if (slideTimer != null && slideTimer.isRunning()) slideTimer.stop();

        slideTimer = new Timer(10, e -> {

            int step = 12;

            if (currentWidth < target) {
                currentWidth += step;
                if (currentWidth >= target) currentWidth = target;
            } else if (currentWidth > target) {
                currentWidth -= step;
                if (currentWidth <= target) currentWidth = target;
            }

            setPreferredSize(new Dimension(currentWidth, getHeight()));
            revalidate();
            repaint();

            if (currentWidth == target) slideTimer.stop();
        });

        slideTimer.start();
    }


    private void installHoverTracking(Component comp) {

        comp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (currentWidth == HIDDEN_WIDTH) return;
                if (closeDelay.isRunning()) closeDelay.stop();
                slideIn();
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                if (currentWidth == HIDDEN_WIDTH) return;
                closeDelay.restart();
            }
        });

        if (comp instanceof Container container) {
            for (Component child : container.getComponents()) {
                installHoverTracking(child);
            }
        }
    }

    private boolean isMouseInsideSidebar() {
        try {
            Point p = MouseInfo.getPointerInfo().getLocation();
            SwingUtilities.convertPointFromScreen(p, this);
            return p.x >= 0 && p.y >= 0 && p.x < getWidth() && p.y < getHeight();
        } catch (Exception ex) {
            return false;
        }
    }


    private JButton menuButton(String icon, String text, Runnable action) {

        JButton btn = new JButton(icon);
        btn.putClientProperty("fullText", icon + "  " + text);
        btn.putClientProperty("iconOnly", icon);

        btn.setMaximumSize(new Dimension(220, 44));
        btn.setAlignmentX(CENTER_ALIGNMENT);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 15));
        btn.setForeground(Color.WHITE);

        btn.setOpaque(true);
        btn.setBackground(bg);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addActionListener(e -> action.run());

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(hoverColor);
                btn.setForeground(borderColor);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(bg);
                btn.setForeground(Color.WHITE);
            }
        });

        menuButtons.add(btn);
        add(Box.createVerticalStrut(8));
        return btn;
    }

    private void updateButtonText(boolean full) {
        for (JButton btn : menuButtons) {
            String f = (String) btn.getClientProperty("fullText");
            String i = (String) btn.getClientProperty("iconOnly");
            if (f != null && i != null)
                btn.setText(full ? f : i);
        }
    }
}
