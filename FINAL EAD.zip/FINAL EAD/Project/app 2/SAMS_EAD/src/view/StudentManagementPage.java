package view;

import controller.StudentController;
import model.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.List;
import java.util.regex.Pattern;

public class StudentManagementPage extends JPanel {

    private final MainFrame frame;
    private final StudentController controller = new StudentController();

    private DefaultTableModel model;
    private JTable table;
    private TableRowSorter<DefaultTableModel> sorter;
    private JTextField txtSearch;

    public StudentManagementPage(MainFrame frame) {
        this.frame = frame;

        setBackground(new Color(20, 22, 40));
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Student Management");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setBorder(BorderFactory.createEmptyBorder(25, 35, 10, 0));
        add(title, BorderLayout.NORTH);


        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        top.setOpaque(false);
        top.setBorder(BorderFactory.createEmptyBorder(0, 35, 10, 35));

        JLabel lblSearch = new JLabel("Search:");
        lblSearch.setForeground(new Color(200, 200, 200));
        lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        txtSearch = new JTextField(22);
        styleTextField(txtSearch);

        JButton btnRefresh = actionButton("Refresh");
        JButton btnDelete = actionButton("Delete Selected");
        JButton btnBack = actionButton("Back");

        top.add(lblSearch);
        top.add(txtSearch);
        top.add(btnRefresh);
        top.add(btnDelete);
        top.add(btnBack);

        add(top, BorderLayout.BEFORE_FIRST_LINE);


        model = new DefaultTableModel(new Object[]{"ID","Name","Age","Grade","Email"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        styleTable(table);

        sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        JScrollPane sp = new JScrollPane(table);
        sp.getViewport().setBackground(new Color(20, 22, 40));
        sp.setBorder(BorderFactory.createEmptyBorder(0, 35, 0, 35));
        add(sp, BorderLayout.CENTER);


        btnRefresh.addActionListener(e -> loadStudents());

        btnDelete.addActionListener(e -> {
            int viewRow = table.getSelectedRow();
            if (viewRow == -1) {
                JOptionPane.showMessageDialog(this, "Select a row first!");
                return;
            }
            int modelRow = table.convertRowIndexToModel(viewRow);
            int id = Integer.parseInt(model.getValueAt(modelRow, 0).toString());

            int ok = JOptionPane.showConfirmDialog(this,
                    "Delete student ID " + id + "?",
                    "Confirm", JOptionPane.YES_NO_OPTION);

            if (ok == JOptionPane.YES_OPTION) {
                if (controller.deleteStudent(id)) {
                    JOptionPane.showMessageDialog(this, "Deleted!");
                    loadStudents();
                } else {
                    JOptionPane.showMessageDialog(this, "Delete failed!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnBack.addActionListener(e -> frame.cardLayout.show(frame.contentPanel, "STUDENT_DASHBOARD"));

        txtSearch.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { applySearch(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { applySearch(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { applySearch(); }
        });


        loadStudents();
    }

    private void loadStudents() {
        model.setRowCount(0);
        List<Student> list = controller.getAllStudents();
        for (Student s : list) {
            model.addRow(new Object[]{ s.getId(), s.getName(), s.getAge(), s.getGrade(), s.getEmail() });
        }
        applySearch();
    }

    private void applySearch() {
        String q = txtSearch.getText().trim();
        if (q.isEmpty()) {
            sorter.setRowFilter(null);
            return;
        }
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(q)));
    }


    private void styleTextField(JTextField tf) {
        tf.setBackground(new Color(32, 36, 60));
        tf.setForeground(Color.WHITE);
        tf.setCaretColor(Color.WHITE);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120, 90, 255)),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
    }

    private JButton actionButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(120, 90, 255));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(new Color(150, 120, 255)); }
            public void mouseExited(java.awt.event.MouseEvent e) { btn.setBackground(new Color(120, 90, 255)); }
        });
        return btn;
    }

    private void styleTable(JTable t) {
        t.setBackground(new Color(32, 36, 60));
        t.setForeground(Color.WHITE);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        t.setRowHeight(30);
        t.setGridColor(new Color(70, 70, 90));
        t.setSelectionBackground(new Color(120, 90, 255));
        t.setSelectionForeground(Color.WHITE);

        t.getTableHeader().setBackground(new Color(40, 45, 80));
        t.getTableHeader().setForeground(Color.WHITE);
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
    }
}
