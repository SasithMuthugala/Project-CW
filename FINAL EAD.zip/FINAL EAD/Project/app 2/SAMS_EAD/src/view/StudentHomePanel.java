package view;

import javax.swing.*;
import java.awt.*;

public class StudentHomePanel extends JPanel {

    public StudentHomePanel() {
        setLayout(new GridBagLayout());
        setOpaque(false);

        JLabel lbl = new JLabel("Student Dashboard");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lbl.setForeground(Color.WHITE);

        add(lbl);
    }
}
