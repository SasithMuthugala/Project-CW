package controller;

import model.LectureAllocation;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LectureAllocationController {

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/sams_db",
                "root",
                ""
        );
    }


    public boolean save(LectureAllocation la) {
        String sql = "INSERT INTO lecture_allocation (lecturer, course, day, time_slot) VALUES (?,?,?,?)";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, la.getLecturer());
            ps.setString(2, la.getCourse());
            ps.setString(3, la.getDay());
            ps.setString(4, la.getTimeSlot());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public List<String> getLecturers() {
        List<String> list = new ArrayList<>();
        list.add("Mr. Silva");
        list.add("Ms. Perera");
        list.add("Dr. Fernando");
        return list;
    }


    public List<String> getCourses() {
        List<String> list = new ArrayList<>();
        list.add("Java");
        list.add("Database");
        list.add("Networking");
        return list;
    }
}
