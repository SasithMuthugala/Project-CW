package controller;

import model.AssessmentResult;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class AssessmentController {

    private final String URL = "jdbc:mysql://localhost:3306/sams_db";
    private final String USER = "root";
    private final String PASS = "";


    public boolean saveResult(AssessmentResult result) {

        String sql = "INSERT INTO assessment_results(student_id, course_id, marks, grade) VALUES(?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, result.getStudent_id());
            ps.setInt(2, result.getCourse_id());
            ps.setInt(3, result.getMarks());
            ps.setString(4, result.getGrade());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public Map<Integer, String> getStudentsMap() {

        Map<Integer, String> map = new LinkedHashMap<>();
        String sql = "SELECT id, name FROM students";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next())
                map.put(rs.getInt("id"), rs.getString("name"));

        } catch (Exception e) {
            e.printStackTrace();
        }

        return map;
    }


    public Map<Integer, String> getCoursesMap() {

        Map<Integer, String> map = new LinkedHashMap<>();
        String sql = "SELECT course_id, course_name FROM courses";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next())
                map.put(rs.getInt("course_id"), rs.getString("course_name"));

        } catch (Exception e) {
            e.printStackTrace();
        }

        return map;
    }


    public Map<String, Integer> getTopCourseAverages() {

        Map<String, Integer> map = new LinkedHashMap<>();

        String sql =
                "SELECT c.course_name, AVG(a.marks) AS avg_marks " +
                        "FROM assessment_results a " +
                        "JOIN courses c ON a.course_id = c.course_id " +
                        "GROUP BY c.course_name " +
                        "ORDER BY avg_marks DESC LIMIT 5";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                map.put(
                        rs.getString("course_name"),
                        (int) Math.round(rs.getDouble("avg_marks"))
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return map;
    }


    public Map<String, Integer> getMarksByStudentId(int studentId) {

        Map<String, Integer> map = new LinkedHashMap<>();

        String sql =
                "SELECT c.course_name, a.marks " +
                        "FROM assessment_results a " +
                        "JOIN courses c ON a.course_id = c.course_id " +
                        "WHERE a.student_id = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();

            while (rs.next())
                map.put(rs.getString("course_name"),
                        rs.getInt("marks"));

        } catch (Exception e) {
            e.printStackTrace();
        }

        return map;
    }
}
