package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AttendanceController {

    private final String URL  = "jdbc:mysql://localhost:3306/sams_db";
    private final String USER = "root";
    private final String PASS = "";


    public List<String> getStudents() {

        List<String> list = new ArrayList<>();
        String sql = "SELECT name FROM students";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(rs.getString("name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }


    public List<String> getCourses() {

        List<String> list = new ArrayList<>();
        String sql = "SELECT course_name FROM courses";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(rs.getString("course_name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }


    public boolean saveAttendance(String studentName, String courseName, String status) {

        String insertSql = "INSERT INTO attendance(student_id, course_id, status) VALUES(?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {

            int studentId = getStudentIdByName(studentName, conn);
            int courseId  = getCourseIdByName(courseName, conn);

            if (studentId == -1 || courseId == -1) {
                return false;
            }

            try (PreparedStatement ps = conn.prepareStatement(insertSql)) {

                ps.setInt(1, studentId);
                ps.setInt(2, courseId);
                ps.setString(3, status);

                ps.executeUpdate();
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public double getAttendancePercentage(String studentName) {

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {

            int studentId = getStudentIdByName(studentName, conn);
            if (studentId == -1) return 0.0;

            int total = 0;
            int present = 0;

            String totalSql = "SELECT COUNT(*) AS total FROM attendance WHERE student_id=?";
            try (PreparedStatement ps = conn.prepareStatement(totalSql)) {
                ps.setInt(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) total = rs.getInt("total");
                }
            }

            String presentSql = "SELECT COUNT(*) AS present FROM attendance WHERE student_id=? AND status='Present'";
            try (PreparedStatement ps = conn.prepareStatement(presentSql)) {
                ps.setInt(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) present = rs.getInt("present");
                }
            }

            if (total == 0) return 0.0;

            return (present * 100.0) / total;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0.0;
    }


    public double getOverallAttendancePercentage() {

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {

            int total = 0;
            int present = 0;

            String totalSql = "SELECT COUNT(*) AS total FROM attendance";
            try (PreparedStatement ps = conn.prepareStatement(totalSql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) total = rs.getInt("total");
            }

            String presentSql = "SELECT COUNT(*) AS present FROM attendance WHERE status='Present'";
            try (PreparedStatement ps = conn.prepareStatement(presentSql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) present = rs.getInt("present");
            }

            if (total == 0) return 0.0;

            return (present * 100.0) / total;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0.0;
    }


    private int getStudentIdByName(String name, Connection conn) throws SQLException {

        String sql = "SELECT id FROM students WHERE name=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, name);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("id");
                return -1;
            }
        }
    }

    private int getCourseIdByName(String courseName, Connection conn) throws SQLException {

        String sql = "SELECT course_id FROM courses WHERE course_name=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, courseName);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("course_id");
                return -1;
            }
        }
    }
}
