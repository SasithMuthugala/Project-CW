package controller;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;
import util.DBConnection;

import javax.swing.*;
import java.io.InputStream;
import java.sql.Connection;

public class AttendanceReportController {

    public void showAttendanceReport() {
        try (Connection con = DBConnection.getConnection()) {

            if (con == null) {
                JOptionPane.showMessageDialog(null, "DB Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }


            InputStream reportStream = getClass().getResourceAsStream("/attendance_report.jrxml");
            if (reportStream == null) {
                JOptionPane.showMessageDialog(null, "Attendance report file not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }


            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, con);


            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setVisible(true);

        } catch (JRException e) {
            JOptionPane.showMessageDialog(null, "Error generating report: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unexpected error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
