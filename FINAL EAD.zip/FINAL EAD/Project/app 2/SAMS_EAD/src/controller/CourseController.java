package controller;

import model.Course;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseController {

    private final String URL = "jdbc:mysql://localhost:3306/sams_db";
    private final String USER = "root";
    private final String PASS = "";

    public boolean saveCourse(Course course) {
        String sql = "INSERT INTO courses(course_name, course_code) VALUES(?, ?)";
        try(Connection conn = DriverManager.getConnection(URL, USER, PASS);
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, course.getCourseName());
            ps.setString(2, course.getCourseCode());
            ps.executeUpdate();
            return true;

        } catch(SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public List<String> getCourses() {
        List<String> list = new ArrayList<>();
        String sql = "SELECT course_name FROM courses";
        try(Connection conn = DriverManager.getConnection(URL, USER, PASS);
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while(rs.next()) {
                list.add(rs.getString("course_name"));
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public int getCourseIdByName(String courseName) {
        String sql = "SELECT course_id FROM courses WHERE course_name=?";
        try(Connection conn = DriverManager.getConnection(URL, USER, PASS);
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, courseName);
            try(ResultSet rs = ps.executeQuery()) {
                if(rs.next()) return rs.getInt("course_id");
            }

        } catch(SQLException e) { e.printStackTrace(); }
        return -1;
    }
}
