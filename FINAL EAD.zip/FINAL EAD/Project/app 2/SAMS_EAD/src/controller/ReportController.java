package controller;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;
import util.DBConnection;

import javax.swing.*;
import java.sql.Connection;

public class ReportController {


    private static JasperViewer currentViewer = null;

    public void showJasperReport() {
        try (Connection con = DBConnection.getConnection()) {

            if (con == null) {
                JOptionPane.showMessageDialog(null, "DB Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }


            if (currentViewer != null) {
                currentViewer.toFront();
                currentViewer.requestFocus();
                return;
            }

            JasperReport jasperReport = JasperCompileManager.compileReport(
                    getClass().getResourceAsStream("/student_report.jrxml")
            );

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, con);

            currentViewer = new JasperViewer(jasperPrint, false);
            currentViewer.setVisible(true);


            currentViewer.addWindowListener(new java.awt.event.WindowAdapter() {
                public void windowClosed(java.awt.event.WindowEvent e) {
                    currentViewer = null;
                }
            });

        } catch (JRException e) {
            JOptionPane.showMessageDialog(null, "Error generating report: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unexpected error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
