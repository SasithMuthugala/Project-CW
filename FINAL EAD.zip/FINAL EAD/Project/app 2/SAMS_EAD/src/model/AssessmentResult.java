package model;

public class AssessmentResult {
    private int result_id;
    private int student_id;
    private int course_id;
    private int marks;
    private String grade;


    public AssessmentResult(int student_id, int course_id, int marks, String grade) {
        this.student_id = student_id;
        this.course_id = course_id;
        this.marks = marks;
        this.grade = grade;
    }


    public AssessmentResult(int result_id, int student_id, int course_id, int marks, String grade) {
        this.result_id = result_id;
        this.student_id = student_id;
        this.course_id = course_id;
        this.marks = marks;
        this.grade = grade;
    }


    public int getResult_id() { return result_id; }
    public int getStudent_id() { return student_id; }
    public int getCourse_id() { return course_id; }
    public int getMarks() { return marks; }
    public String getGrade() { return grade; }


    public void setResult_id(int result_id) { this.result_id = result_id; }
    public void setStudent_id(int student_id) { this.student_id = student_id; }
    public void setCourse_id(int course_id) { this.course_id = course_id; }
    public void setMarks(int marks) { this.marks = marks; }
    public void setGrade(String grade) { this.grade = grade; }
}
