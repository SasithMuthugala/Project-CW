package model;

public class LectureAllocation {

    private String lecturer;
    private String course;
    private String day;
    private String timeSlot;

    public LectureAllocation(String lecturer, String course, String day, String timeSlot) {
        this.lecturer = lecturer;
        this.course = course;
        this.day = day;
        this.timeSlot = timeSlot;
    }

    public String getLecturer() { return lecturer; }
    public String getCourse() { return course; }
    public String getDay() { return day; }
    public String getTimeSlot() { return timeSlot; }
}
