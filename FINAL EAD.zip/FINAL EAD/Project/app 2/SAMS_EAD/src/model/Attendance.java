package model;

public class Attendance {
    private String student_id;
    private String date;
    private String status;

    public Attendance(String student_id, String date, String status) {
        this.student_id = student_id;
        this.date = date;
        this.status = status;
    }

    public String getStudent() { return student_id; }
    public String getDate() { return date; }
    public String getStatus() { return status; }
}
