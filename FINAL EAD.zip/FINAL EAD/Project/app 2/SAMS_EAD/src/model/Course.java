package model;

public class Course {
    private int course_id;
    private String course_name;
    private String course_code;
    private int credits;
    private String instructor;


    public Course(String course_name, String course_code) {
        this.course_name = course_name;
        this.course_code = course_code;
    }


    public int getCourseId() { return course_id; }
    public String getCourseName() { return course_name; }
    public String getCourseCode() { return course_code; }
    public int getCredits() { return credits; }
    public String getInstructor() { return instructor; }


    public void setCourseId(int id) { this.course_id = id; }
    public void setCourseName(String name) { this.course_name = name; }
    public void setCourseCode(String code) { this.course_code = code; }
    public void setCredits(int credits) { this.credits = credits; }
    public void setInstructor(String instructor) { this.instructor = instructor; }
}
